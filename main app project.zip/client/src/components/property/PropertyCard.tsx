import React from 'react';
import { Link } from 'react-router-dom';
import { MapPinIcon, CurrencyDollarIcon, HeartIcon } from '../icons';
import Card from '../ui/Card';
import Button from '../ui/Button';

interface Property {
  id: string;
  address: string;
  neighborhood: string;
  borough: string;
  propertyType: string;
  beds: number;
  baths: string;
  sqft: number;
  price: string;
  estimatedProfit?: string;
  capRate?: string;
  images: string[];
  description: string;
}

interface PropertyCardProps {
  property: Property;
  onMakeOffer?: (property: Property) => void;
  animationDelay?: number;
}

const PropertyCard: React.FC<PropertyCardProps> = ({ 
  property, 
  onMakeOffer, 
  animationDelay = 0 
}) => {
  const formatPrice = (price: string) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
    }).format(parseInt(price));
  };

  return (
    <Card 
      variant="property" 
      className="group animate-slide-up relative overflow-hidden"
      style={{ animationDelay: `${animationDelay}s` }}
    >
      {/* Modern Image Container with Gradient Overlay */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-t from-primary-blue/60 via-transparent to-transparent z-10"></div>
        <img 
          src={property.images[0] || 'https://images.unsplash.com/photo-1666585607888-3f6fe0b323d8?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NTAwNDR8MHwxfHNlYXJjaHw2fHxsdXh1cnklMjBhcGFydG1lbnQlMjBtb2Rlcm4lMjBpbnRlcmlvciUyMGZsb29yJTIwdG8lMjBjZWlsaW5nJTIwd2luZG93cyUyMGNpdHklMjB2aWV3fGVufDB8MHx8fDE3NTg2MTU5Mzh8MA&ixlib=rb-4.1.0&q=85'} 
          alt={`${property.address} - Modern luxury apartment interior with floor to ceiling windows and city view - S.Group Official on Unsplash`}
          className="w-full h-72 object-cover group-hover:scale-110 transition-transform duration-700"
          style={{ width: '100%', height: '288px' }}
        />
        
        {/* Floating Action Buttons */}
        <div className="absolute top-4 right-4 z-20">
          <button className="p-3 bg-white/20 backdrop-blur-md rounded-full hover:bg-white/30 transition-all duration-300 animate-pulse-glow">
            <HeartIcon className="w-5 h-5 text-white" />
          </button>
        </div>
        
        {/* Property Type Badge */}
        <div className="absolute bottom-4 left-4 z-20">
          <span className="px-4 py-2 bg-glass-bg-strong backdrop-blur-md text-white text-sm rounded-full border border-glass-border font-medium">
            {property.propertyType}
          </span>
        </div>
        
        {/* Price Overlay */}
        <div className="absolute bottom-4 right-4 z-20">
          <div className="flex items-center bg-glass-bg-dark backdrop-blur-md rounded-full px-4 py-2 border border-glass-border-dark">
            <CurrencyDollarIcon className="w-5 h-5 mr-1 text-accent-yellow" />
            <span className="text-white font-bold text-lg">
              {formatPrice(property.price)}
            </span>
          </div>
        </div>
      </div>
      
      {/* Enhanced Content Section */}
      <div className="p-8 relative">
        {/* Floating Geometric Shape */}
        <div className="absolute -top-6 right-6 w-12 h-12 bg-gradient-gold rounded-full opacity-20 animate-float"></div>
        
        <div className="mb-6">
          <h3 className="text-xl font-bold text-primary-blue group-hover:text-accent-yellow transition-colors duration-300 mb-2">
            {property.address}
          </h3>
          <div className="flex items-center text-neutral-600">
            <MapPinIcon className="w-4 h-4 mr-2 text-accent-yellow" />
            <span className="text-sm font-medium">{property.neighborhood}, {property.borough}</span>
          </div>
        </div>
        
        {/* Modern Stats Grid */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="text-center p-4 bg-gradient-to-br from-primary-blue-50 to-primary-blue-100 rounded-2xl border border-primary-blue-200 group-hover:shadow-lg transition-all duration-300">
            <div className="text-2xl font-bold text-primary-blue mb-1">{property.beds}</div>
            <div className="text-xs text-neutral-600 font-medium uppercase tracking-wide">Beds</div>
          </div>
          <div className="text-center p-4 bg-gradient-to-br from-accent-yellow-50 to-accent-yellow-100 rounded-2xl border border-accent-yellow-200 group-hover:shadow-lg transition-all duration-300">
            <div className="text-2xl font-bold text-accent-yellow mb-1">{property.baths}</div>
            <div className="text-xs text-neutral-600 font-medium uppercase tracking-wide">Baths</div>
          </div>
          <div className="text-center p-4 bg-gradient-to-br from-success-emerald-50 to-success-emerald-100 rounded-2xl border border-success-emerald-200 group-hover:shadow-lg transition-all duration-300">
            <div className="text-2xl font-bold text-success-emerald mb-1">{property.sqft?.toLocaleString()}</div>
            <div className="text-xs text-neutral-600 font-medium uppercase tracking-wide">SqFt</div>
          </div>
        </div>

        {/* Investment Metrics */}
        <div className="space-y-3 mb-6">
          {property.estimatedProfit && (
            <div className="bg-gradient-gold p-4 rounded-2xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-20 h-20 bg-white/10 rounded-full -mr-10 -mt-10"></div>
              <div className="text-white text-center relative z-10">
                <div className="text-sm font-medium mb-1">Estimated Profit</div>
                <div className="text-2xl font-bold">{formatPrice(property.estimatedProfit)}</div>
              </div>
            </div>
          )}

          {property.capRate && (
            <div className="bg-gradient-success p-4 rounded-2xl relative overflow-hidden">
              <div className="absolute bottom-0 left-0 w-16 h-16 bg-white/10 rounded-full -ml-8 -mb-8"></div>
              <div className="text-white text-center relative z-10">
                <div className="text-sm font-medium mb-1">Cap Rate</div>
                <div className="text-2xl font-bold">{property.capRate}%</div>
              </div>
            </div>
          )}
        </div>

        <p className="text-neutral-600 text-sm mb-8 line-clamp-2 leading-relaxed">
          {property.description}
        </p>

        {/* Enhanced Action Buttons */}
        <div className="flex gap-4">
          <Link 
            to={`/properties/${property.id}`}
            className="flex-1"
          >
            <Button variant="outline" className="w-full py-3 rounded-2xl font-semibold border-2 hover:border-primary-blue hover:bg-primary-blue hover:text-white transition-all duration-300">
              View Details
            </Button>
          </Link>
          {onMakeOffer && (
            <Button
              variant="success"
              onClick={() => onMakeOffer(property)}
              className="flex-1 py-3 rounded-2xl font-semibold bg-gradient-success hover:shadow-xl transform hover:scale-105 transition-all duration-300"
            >
              Make Offer
            </Button>
          )}
        </div>
      </div>
      
      {/* Subtle Border Glow Effect */}
      <div className="absolute inset-0 rounded-3xl bg-gradient-to-r from-accent-yellow/20 via-transparent to-success-emerald/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"></div>
    </Card>
  );
};

export default PropertyCard;