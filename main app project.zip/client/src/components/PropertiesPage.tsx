import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Link } from 'react-router-dom';
import { 
  MagnifyingGlassIcon, 
  FunnelIcon, 
  AdjustmentsVerticalIcon,
  Bars3Icon,
  HomeIcon,
  LockClosedIcon,
  Squares2X2Icon
} from './icons';
import PropertyCard from './property/PropertyCard';
import PropertyListItem from './property/PropertyListItem';
import Button from './ui/Button';
import Input from './ui/Input';
import Select from './ui/Select';
import Card from './ui/Card';

interface Property {
  id: string;
  address: string;
  neighborhood: string;
  borough: string;
  propertyType: string;
  beds: number;
  baths: string;
  sqft: number;
  price: string;
  estimatedProfit?: string;
  capRate?: string;
  images: string[];
  description: string;
}

const PropertiesPage: React.FC = () => {
  console.log('PropertiesPage component rendering');
  const { user } = useAuth();
  const [properties, setProperties] = useState<Property[]>([]);
  const [filteredProperties, setFilteredProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    borough: '',
    propertyType: '',
    minPrice: '',
    maxPrice: '',
    beds: '',
    searchTerm: '',
    sortBy: 'newest'
  });
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 9;

  useEffect(() => {
    fetchProperties();
  }, []);

  useEffect(() => {
    console.log('Properties updated:', properties);
    console.log('Filtered properties updated:', filteredProperties);
  }, [properties, filteredProperties]);

  useEffect(() => {
    // Re-apply filters when view mode or page changes
    if (properties.length > 0) {
      applyFilters();
    }
  }, [viewMode, currentPage]);

  useEffect(() => {
    if (properties.length > 0) {
      applyFilters();
    } else if (properties.length === 0 && filteredProperties.length > 0) {
      // Reset filtered properties when properties is empty
      setFilteredProperties([]);
    }
  }, [properties, filters]);

  const fetchProperties = async () => {
    try {
      console.log('Fetching properties...');
      const response = await fetch('/api/public/properties');
      console.log('Response status:', response.status);
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      console.log('Fetched data:', data);
      
      // Validate the data
      if (Array.isArray(data)) {
        console.log('Valid data received, setting properties');
        setProperties(data);
        setFilteredProperties(data); // Set filtered properties initially
      } else {
        console.log('Invalid data received, using fallback');
        throw new Error('Invalid data format');
      }
    } catch (error) {
      console.error('Error fetching properties:', error);
      // Fallback to sample data if API fails
      console.log('Using sample data as fallback');
      const sampleData = [
        {
          id: '1',
          address: '123 Main St',
          neighborhood: 'Downtown',
          borough: 'Manhattan',
          propertyType: 'Single Family',
          beds: 3,
          baths: '2',
          sqft: 1500,
          price: '450000',
          estimatedProfit: '75000',
          capRate: '12.5',
          images: ['https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80'],
          description: 'Beautiful modern home with updated kitchen and spacious backyard.'
        },
        {
          id: '2',
          address: '456 Park Ave',
          neighborhood: 'Midtown',
          borough: 'Manhattan',
          propertyType: 'Apartment',
          beds: 2,
          baths: '1',
          sqft: 1200,
          price: '650000',
          estimatedProfit: '95000',
          capRate: '14.2',
          images: ['https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80'],
          description: 'Luxury apartment with city views and premium amenities.'
        }
      ];
      console.log('Setting sample data:', sampleData);
      setProperties(sampleData);
      setFilteredProperties(sampleData);
    } finally {
      console.log('Finished loading properties');
      setLoading(false);
    }
  };

  const applyFilters = () => {
    console.log('Applying filters...', filters);
    let filtered = [...properties];

    if (filters.borough) {
      filtered = filtered.filter(p => p.borough === filters.borough);
    }

    if (filters.propertyType) {
      filtered = filtered.filter(p => p.propertyType === filters.propertyType);
    }

    if (filters.minPrice) {
      filtered = filtered.filter(p => parseInt(p.price) >= parseInt(filters.minPrice));
    }
    if (filters.maxPrice) {
      filtered = filtered.filter(p => parseInt(p.price) <= parseInt(filters.maxPrice));
    }

    if (filters.beds) {
      filtered = filtered.filter(p => p.beds >= parseInt(filters.beds));
    }

    if (filters.searchTerm) {
      const term = filters.searchTerm.toLowerCase();
      filtered = filtered.filter(p => 
        p.address.toLowerCase().includes(term) ||
        p.neighborhood.toLowerCase().includes(term) ||
        p.description.toLowerCase().includes(term)
      );
    }

    console.log('Filtered properties:', filtered);
    setFilteredProperties(filtered);
  };

  const handleFilterChange = (key: string, value: string) => {
    console.log(`Filter change: ${key} = ${value}`);
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const clearFilters = () => {
    console.log('Clearing filters');
    setFilters({
      borough: '',
      propertyType: '',
      minPrice: '',
      maxPrice: '',
      beds: '',
      searchTerm: '',
      sortBy: 'newest'
    });
  };

  const resetFilters = () => {
    console.log('Resetting filters');
    clearFilters();
    setViewMode('grid');
    setCurrentPage(1);
  };


  const handleMakeOffer = (property: Property) => {
    console.log('Make offer clicked for property:', property);
    if (!user) {
      window.location.href = '/auth/investor';
      return;
    }
    // Handle offer logic here
  };

  const boroughs = ['Manhattan', 'Brooklyn', 'Queens', 'Bronx', 'Staten Island'];
  const propertyTypes = ['Single Family', 'Multi-Family', 'Condo', 'Townhouse', 'Commercial'];

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-primary">
        <div className="text-xl text-white animate-pulse">Loading properties...</div>
      </div>
    );
  }

  console.log('Rendering properties page with:', { properties, filteredProperties, loading });
  
  // Simple test to ensure the component is rendering
  if (properties.length === 0 && filteredProperties.length === 0) {
    console.log('No properties found - this might be the issue');
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-neutral-50 via-white to-neutral-100">
      {/* Hero Section */}
      <section className="bg-gradient-hero text-white py-24 relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-10 left-10 w-32 h-32 bg-accent-yellow/20 rounded-full animate-float backdrop-blur-sm"></div>
          <div className="absolute bottom-10 right-10 w-24 h-24 bg-success-emerald/20 rounded-full animate-float-delayed backdrop-blur-sm"></div>
        </div>
        
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="heading-hero mb-8">
              Exclusive Property Listings
            </h1>
            <p className="text-xl md:text-2xl text-neutral-100 mb-12 leading-relaxed">
              Discover off-market wholesale properties and foreclosure opportunities 
              across New York City's five boroughs
            </p>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 py-16">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters Sidebar */}
          <div className="lg:w-1/4">
            <div className="sticky top-4">
              <Card variant="modern" className="p-6 mb-6">
                <h3 className="text-xl font-bold text-primary-blue mb-6">Search & Filter</h3>
                
                <form onSubmit={(e) => { e.preventDefault(); }} className="space-y-6">
                  {/* Search */}
                  <div>
                    <label htmlFor="search" className="block text-sm font-semibold text-primary-blue mb-2">
                      Search
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        id="search"
                        placeholder="Address, neighborhood, or ZIP"
                        className="w-full px-4 py-3 rounded-xl border border-neutral-300 focus:border-primary-blue focus:ring-2 focus:ring-primary-blue transition-all duration-300"
                        value={filters.searchTerm}
                        onChange={(e) => {
                          console.log('Search term change:', e.target.value);
                          handleFilterChange('searchTerm', e.target.value);
                        }}
                      />
                      <MagnifyingGlassIcon className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-neutral-400" />
                    </div>
                  </div>
                  
                  {/* Location */}
                  <div>
                    <label className="block text-sm font-semibold text-primary-blue mb-2">
                      Location
                    </label>
                    <Select
                      options={[
                        { value: '', label: 'All Boroughs' },
                        { value: 'Manhattan', label: 'Manhattan' },
                        { value: 'Brooklyn', label: 'Brooklyn' },
                        { value: 'Queens', label: 'Queens' },
                        { value: 'Bronx', label: 'Bronx' },
                        { value: 'Staten Island', label: 'Staten Island' }
                      ]}
                      value={filters.borough}
                      onChange={(e) => handleFilterChange('borough', e.target.value)}
                      className="w-full"
                    />
                  </div>
                  
                  {/* Property Type */}
                  <div>
                    <label className="block text-sm font-semibold text-primary-blue mb-2">
                      Property Type
                    </label>
                    <Select
                      options={[
                        { value: '', label: 'All Types' },
                        { value: 'Single Family', label: 'Single Family' },
                        { value: 'Multi Family', label: 'Multi Family' },
                        { value: 'Apartment', label: 'Apartment' },
                        { value: 'Commercial', label: 'Commercial' },
                        { value: 'Land', label: 'Land' }
                      ]}
                      value={filters.propertyType}
                      onChange={(e) => handleFilterChange('propertyType', e.target.value)}
                      className="w-full"
                    />
                  </div>
                  
                  {/* Price Range */}
                  <div>
                    <label className="block text-sm font-semibold text-primary-blue mb-2">
                      Price Range
                    </label>
                    <div className="grid grid-cols-2 gap-3">
                      <input
                        type="number"
                        placeholder="Min"
                        className="w-full px-4 py-3 rounded-xl border border-neutral-300 focus:border-primary-blue focus:ring-2 focus:ring-primary-blue transition-all duration-300"
                        value={filters.minPrice || ''}
                        onChange={(e) => handleFilterChange('minPrice', e.target.value || '')}
                      />
                      <input
                        type="number"
                        placeholder="Max"
                        className="w-full px-4 py-3 rounded-xl border border-neutral-300 focus:border-primary-blue focus:ring-2 focus:ring-primary-blue transition-all duration-300"
                        value={filters.maxPrice || ''}
                        onChange={(e) => handleFilterChange('maxPrice', e.target.value || '')}
                      />
                    </div>
                  </div>
                  
                  {/* Beds */}
                  <div>
                    <label className="block text-sm font-semibold text-primary-blue mb-2">
                      Bedrooms
                    </label>
                    <Select
                      options={[
                        { value: '', label: 'Any' },
                        { value: '1', label: '1+' },
                        { value: '2', label: '2+' },
                        { value: '3', label: '3+' },
                        { value: '4', label: '4+' }
                      ]}
                      value={filters.beds}
                      onChange={(e) => handleFilterChange('beds', e.target.value)}
                      className="w-full"
                    />
                  </div>
                  
                  {/* Sort By */}
                  <div>
                    <label className="block text-sm font-semibold text-primary-blue mb-2">
                      Sort By
                    </label>
                    <Select
                      options={[
                        { value: 'newest', label: 'Newest First' },
                        { value: 'price-low', label: 'Price: Low to High' },
                        { value: 'price-high', label: 'Price: High to Low' },
                        { value: 'profit-high', label: 'Profit: High to Low' }
                      ]}
                      value={filters.sortBy}
                      onChange={(e) => handleFilterChange('sortBy', e.target.value)}
                      className="w-full"
                    />
                  </div>
                  
                  {/* Action Buttons */}
                  <div className="flex gap-3">
                    <button
                      type="submit"
                      className="flex-1 btn-primary py-3 rounded-2xl font-semibold"
                    >
                      Apply Filters
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        console.log('Reset button clicked');
                        resetFilters();
                      }}
                      className="px-4 py-3 border border-neutral-300 rounded-2xl font-semibold text-neutral-600 hover:bg-neutral-50 transition-colors"
                    >
                      Reset
                    </button>
                  </div>
                </form>
              </Card>
              
              {/* Premium Access Banner */}
              <Card variant="modern" className="p-6">
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-gold rounded-full flex items-center justify-center mx-auto mb-4">
                    <LockClosedIcon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-lg font-bold text-primary-blue mb-2">Premium Access</h3>
                  <p className="text-neutral-600 text-sm mb-4">
                    Get exclusive access to our full property database with advanced search filters and investment analysis.
                  </p>
                  <Link to="/auth/investor" className="text-accent-yellow hover:text-accent-yellow-dark font-medium text-sm">
                    Join as Investor →
                  </Link>
                </div>
              </Card>
            </div>
          </div>

          {/* Properties Grid */}
          <div className="lg:w-3/4">
            {/* Results Header */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4">
              <div>
                <h2 className="text-2xl font-bold text-primary-blue">
                  {filteredProperties.length} Properties Found
                </h2>
                <p className="text-neutral-600">
                  Exclusive off-market opportunities with verified profit potential
                </p>
              </div>
              
              <div className="flex items-center space-x-4">
                <span className="text-sm text-neutral-600">View:</span>
                <div className="flex bg-neutral-100 rounded-lg p-1">
                  <button
                    onClick={() => {
                      console.log('Switching to grid view');
                      setViewMode('grid');
                    }}
                    className={`p-2 rounded-md ${
                      viewMode === 'grid' 
                        ? 'bg-white shadow-sm text-primary-blue' 
                        : 'text-neutral-500 hover:text-neutral-700'
                    }`}
                  >
                    <Squares2X2Icon className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => {
                      console.log('Switching to list view');
                      setViewMode('list');
                    }}
                    className={`p-2 rounded-md ${
                      viewMode === 'list' 
                        ? 'bg-white shadow-sm text-primary-blue' 
                        : 'text-neutral-500 hover:text-neutral-700'
                    }`}
                  >
                    <Bars3Icon className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>

            {/* Properties List */}
            {loading ? (
              <div className="flex justify-center items-center h-64">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-blue"></div>
              </div>
            ) : (
              <>
                {viewMode === 'grid' ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
                    {filteredProperties
                      .slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage)
                      .map((property, index) => (
                        <div key={property.id} className="animate-slide-up" style={{ animationDelay: `${index * 0.1}s` }}>
                          <PropertyCard 
                            property={property}
                            onMakeOffer={handleMakeOffer}
                            animationDelay={index * 0.1}
                          />
                        </div>
                      ))
                    }
                  </div>
                ) : (
                  <div className="space-y-6">
                    {filteredProperties
                      .slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage)
                      .map((property, index) => (
                        <div key={property.id} className="animate-slide-up" style={{ animationDelay: `${index * 0.1}s` }}>
                          <PropertyListItem 
                            property={property}
                            onMakeOffer={handleMakeOffer}
                          />
                        </div>
                      ))
                    }
                  </div>
                )}

                {/* Pagination */}
                {Math.ceil(filteredProperties.length / itemsPerPage) > 1 && (
                  <div className="flex justify-center mt-12">
                    <div className="flex space-x-2">
                      {Array.from({ length: Math.ceil(filteredProperties.length / itemsPerPage) }, (_, i) => i + 1).map(page => (
                        <button
                          key={page}
                          onClick={() => {
                            console.log(`Setting current page to ${page}`);
                            setCurrentPage(page);
                          }}
                          className={`w-10 h-10 rounded-full flex items-center justify-center ${
                            currentPage === page
                              ? 'bg-primary-blue text-white font-medium'
                              : 'bg-neutral-100 text-neutral-600 hover:bg-accent-yellow/10 hover:text-accent-yellow'
                          }`}
                        >
                          {page}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}

            {/* No Results */}
            {!loading && filteredProperties.length === 0 && (
              <Card variant="modern" className="p-12 text-center">
                <div className="w-16 h-16 bg-neutral-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <HomeIcon className="w-8 h-8 text-neutral-400" />
                </div>
                <h3 className="text-xl font-bold text-primary-blue mb-2">No Properties Found</h3>
                <p className="text-neutral-600 mb-6">
                  Try adjusting your filters or check back later for new listings.
                </p>
                <div className="text-sm text-neutral-500 mt-4">
                  Properties loaded: {properties.length}
                </div>
                <button
                  onClick={() => {
                    console.log('Reset filters button clicked');
                    resetFilters();
                  }}
                  className="btn-primary px-6 py-3 rounded-2xl font-semibold mt-4"
                >
                  Reset Filters
                </button>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PropertiesPage;