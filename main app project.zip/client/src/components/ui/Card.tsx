import React from 'react';

interface CardProps {
  children: React.ReactNode;
  variant?: 'modern' | 'glass' | 'property';
  className?: string;
  hover?: boolean;
  style?: React.CSSProperties;
}

const Card: React.FC<CardProps> = ({ 
  children, 
  variant = 'modern', 
  className = '', 
  hover = false,
  style
}) => {
  const baseClasses = 'rounded-2xl overflow-hidden';
  
  const variantClasses = {
    modern: 'card-modern',
    glass: 'card-glass',
    property: 'card-property'
  };

  const hoverClasses = hover ? 'hover:shadow-xl hover:-translate-y-2' : '';

  const classes = `${baseClasses} ${variantClasses[variant]} ${hoverClasses} ${className}`;

  return (
    <div className={classes} style={style}>
      {children}
    </div>
  );
};

export default Card;