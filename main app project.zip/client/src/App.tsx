import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import Header from './components/layout/Header';
import Footer from './components/layout/Footer';
import LandingPage from './components/LandingPage';
import PropertiesPage from './components/PropertiesPage';
import ForeclosurePage from './components/ForeclosurePage';
import AboutPage from './components/AboutPage';
import BlogPage from './components/BlogPage';
import ContactPage from './components/ContactPage';
import FaqPage from './components/FaqPage';
import InvestorAuth from './components/auth/InvestorAuth';
// import EnhancedInvestorAuth from './components/auth/EnhancedInvestorAuth';
import SellerAuth from './components/auth/SellerAuth';
// Missing components commented out:
// import CommonInvestorDashboard from './components/dashboard/CommonInvestorDashboard';
// import InstitutionalDashboard from './components/dashboard/InstitutionalDashboard';
// import SellerDashboard from './components/dashboard/SellerDashboard';
// import EnhancedSellerPortal from './components/seller/EnhancedSellerPortal';
// import ProfileSettings from './components/dashboard/ProfileSettings';
// import SubscriptionManagement from './components/dashboard/SubscriptionManagement';
// import EnhancedForeclosureSubscription from './components/subscription/EnhancedForeclosureSubscription';
// import SubscriptionAnalytics from './components/subscription/SubscriptionAnalytics';
// import OfferManagement from './components/offers/OfferManagement';
// import SellerOfferManagement from './components/offers/SellerOfferManagement';
// import AddPropertyForm from './components/seller/AddPropertyForm';
// import PropertyManagement from './components/seller/PropertyManagement';
// import AdminDashboard from './components/admin/AdminDashboard';
// import UserManagement from './components/admin/UserManagement';
// import PropertyApproval from './components/admin/PropertyApproval';
// import Analytics from './components/admin/Analytics';
// import EmailCampaigns from './components/admin/EmailCampaigns';
// import SecurityMonitoring from './components/admin/SecurityMonitoring';

const AppContent: React.FC = () => {
  const { user, loading, logout } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-xl">Loading...</div>
      </div>
    );
  }

  // Create a compatible user object for Header component
  const headerUser = user ? {
    ...user,
    // Ensure username is always a string for Header component
    username: user.username || '',
    // Ensure firstName and lastName are always strings for Header component
    firstName: user.firstName || '',
    lastName: user.lastName || ''
  } : null;

  // Simplified dashboard route - redirect to properties for now since dashboard components don't exist
  const getDashboardRoute = () => {
    if (!user) return <Navigate to="/auth/investor" replace />;

    // For now, redirect all authenticated users to properties page
    // TODO: Implement proper dashboard components
    return <Navigate to="/properties" replace />;
  };

  return (
    <Router>
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <Header user={headerUser} onLogout={logout} />
        
        <main className="flex-grow">
          <Routes>
            {/* Public Routes */}
            <Route path="/" element={<LandingPage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/properties" element={<PropertiesPage />} />
            <Route path="/foreclosures" element={<ForeclosurePage />} />
            <Route path="/blog" element={<BlogPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/faq" element={<FaqPage />} />

            {/* Authentication Routes */}
            <Route path="/auth/investor" element={user ? <Navigate to="/dashboard" replace /> : <InvestorAuth />} />
            <Route path="/auth/seller" element={user ? <Navigate to="/dashboard" replace /> : <SellerAuth />} />

            {/* Protected Routes - Simplified Dashboard */}
            {user ? (
              <>
                <Route path="/dashboard" element={getDashboardRoute()} />
                {/* TODO: Add dashboard routes when components are available */}
              </>
            ) : (
              <Route path="/dashboard/*" element={<Navigate to="/auth/investor" replace />} />
            )}

            {/* Catch all route */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
        
        <Footer />
      </div>
    </Router>
  );
};

const App: React.FC = () => {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
};

export default App;