/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./client/index.html",
    "./client/src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#eff6ff',
          500: '#3b82f6',
          600: '#2563eb',
          700: '#1d4ed8',
          900: '#1e3a8a',
          navy: '#1e3a8a',
        },
        accent: {
          yellow: '#fbbf24',
          gold: '#fbbf24',
        },
        success: {
          emerald: '#10b981',
        },
        neutral: {
          100: '#f5f5f5',
          300: '#d1d5db',
          400: '#9ca3af',
          500: '#6b7280',
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
