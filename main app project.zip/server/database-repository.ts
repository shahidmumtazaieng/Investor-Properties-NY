import { supabase, db } from './database.ts';
import { eq, and, gte, desc } from 'drizzle-orm';
import * as schema from '../shared/schema.ts';
import bcrypt from 'bcrypt';
import { randomUUID } from 'crypto';

/**
 * Database Repository - Handles all database operations
 * Provides methods for CRUD operations on all entities
 */
export class DatabaseRepository {
  // ==================== USERS ====================
  async getAllUsers() {
    return await db.select().from(schema.users);
  }

  async getUserById(id: string) {
    const result = await db.select().from(schema.users).where(eq(schema.users.id, id));
    return result[0] || null;
  }

  async getUserByUsername(username: string) {
    const result = await db.select().from(schema.users).where(eq(schema.users.username, username));
    return result[0] || null;
  }

  async createUser(userData: any) {
    const result = await db.insert(schema.users).values(userData).returning();
    return result[0];
  }

  async updateUser(id: string, userData: any) {
    const result = await db.update(schema.users)
      .set({ ...userData, updatedAt: new Date() })
      .where(eq(schema.users.id, id))
      .returning();
    return result[0];
  }

  // ==================== PROPERTIES ====================
  async getAllProperties() {
    return await db.select().from(schema.properties)
      .where(eq(schema.properties.isActive, true))
      .orderBy(desc(schema.properties.createdAt));
  }

  async getPropertyById(id: string) {
    const result = await db.select().from(schema.properties).where(eq(schema.properties.id, id));
    return result[0] || null;
  }

  async createProperty(propertyData: any) {
    const result = await db.insert(schema.properties).values(propertyData).returning();
    return result[0];
  }

  async updateProperty(id: string, propertyData: any) {
    const result = await db.update(schema.properties)
      .set({ ...propertyData, updatedAt: new Date() })
      .where(eq(schema.properties.id, id))
      .returning();
    return result[0];
  }

  async deleteProperty(id: string) {
    const result = await db.update(schema.properties)
      .set({ isActive: false, updatedAt: new Date() })
      .where(eq(schema.properties.id, id))
      .returning();
    return result[0];
  }

  // ==================== PARTNERS ====================
  async getAllPartners() {
    return await db.select().from(schema.partners)
      .where(eq(schema.partners.isActive, true));
  }

  async getPartnerById(id: string) {
    const result = await db.select().from(schema.partners).where(eq(schema.partners.id, id));
    return result[0] || null;
  }

  async getPartnerByUsername(username: string) {
    const result = await db.select().from(schema.partners).where(eq(schema.partners.username, username));
    return result[0] || null;
  }

  async createPartner(partnerData: any) {
    const result = await db.insert(schema.partners).values(partnerData).returning();
    return result[0];
  }

  async updatePartner(id: string, partnerData: any) {
    const result = await db.update(schema.partners)
      .set({ ...partnerData, updatedAt: new Date() })
      .where(eq(schema.partners.id, id))
      .returning();
    return result[0];
  }

  // ==================== COMMON INVESTORS ====================
  async getAllCommonInvestors() {
    return await db.select().from(schema.commonInvestors)
      .where(eq(schema.commonInvestors.isActive, true));
  }

  async getCommonInvestorById(id: string) {
    const result = await db.select().from(schema.commonInvestors).where(eq(schema.commonInvestors.id, id));
    return result[0] || null;
  }

  async getCommonInvestorByUsername(username: string) {
    const result = await db.select().from(schema.commonInvestors).where(eq(schema.commonInvestors.username, username));
    return result[0] || null;
  }

  async createCommonInvestor(investorData: any) {
    const result = await db.insert(schema.commonInvestors).values(investorData).returning();
    return result[0];
  }

  async updateCommonInvestor(id: string, investorData: any) {
    const result = await db.update(schema.commonInvestors)
      .set({ ...investorData, updatedAt: new Date() })
      .where(eq(schema.commonInvestors.id, id))
      .returning();
    return result[0];
  }

  async getCommonInvestorsWithForeclosureSubscription() {
    return await db.select().from(schema.commonInvestors)
      .where(
        and(
          eq(schema.commonInvestors.isActive, true),
          eq(schema.commonInvestors.hasForeclosureSubscription, true),
          gte(schema.commonInvestors.foreclosureSubscriptionExpiry, new Date())
        )
      );
  }

  // ==================== INSTITUTIONAL INVESTORS ====================
  async getAllInstitutionalInvestors() {
    return await db.select().from(schema.institutionalInvestors)
      .where(eq(schema.institutionalInvestors.isActive, true));
  }

  async getInstitutionalInvestorById(id: string) {
    const result = await db.select().from(schema.institutionalInvestors)
      .where(eq(schema.institutionalInvestors.id, id));
    return result[0] || null;
  }

  async getInstitutionalInvestorByUsername(username: string) {
    const result = await db.select().from(schema.institutionalInvestors)
      .where(eq(schema.institutionalInvestors.username, username));
    return result[0] || null;
  }

  async createInstitutionalInvestor(investorData: any) {
    const result = await db.insert(schema.institutionalInvestors).values(investorData).returning();
    return result[0];
  }

  async updateInstitutionalInvestor(id: string, investorData: any) {
    const result = await db.update(schema.institutionalInvestors)
      .set({ ...investorData, updatedAt: new Date() })
      .where(eq(schema.institutionalInvestors.id, id))
      .returning();
    return result[0];
  }

  // ==================== FORECLOSURE LISTINGS ====================
  async getAllForeclosureListings() {
    return await db.select().from(schema.foreclosureListings)
      .where(eq(schema.foreclosureListings.isActive, true))
      .orderBy(desc(schema.foreclosureListings.createdAt));
  }

  async getForeclosureListingById(id: string) {
    const result = await db.select().from(schema.foreclosureListings)
      .where(eq(schema.foreclosureListings.id, id));
    return result[0] || null;
  }

  async createForeclosureListing(listingData: any) {
    const result = await db.insert(schema.foreclosureListings).values(listingData).returning();
    return result[0];
  }

  async updateForeclosureListing(id: string, listingData: any) {
    const result = await db.update(schema.foreclosureListings)
      .set({ ...listingData, updatedAt: new Date() })
      .where(eq(schema.foreclosureListings.id, id))
      .returning();
    return result[0];
  }

  // ==================== OFFERS ====================
  async getAllOffers() {
    return await db.select().from(schema.offers)
      .orderBy(desc(schema.offers.createdAt));
  }

  async getOfferById(id: string) {
    const result = await db.select().from(schema.offers).where(eq(schema.offers.id, id));
    return result[0] || null;
  }

  async getOffersByPropertyId(propertyId: string) {
    return await db.select().from(schema.offers)
      .where(eq(schema.offers.propertyId, propertyId))
      .orderBy(desc(schema.offers.createdAt));
  }

  async getOffersByBuyerId(buyerId: string) {
    return await db.select().from(schema.offers)
      .where(eq(schema.offers.buyerLeadId, buyerId))
      .orderBy(desc(schema.offers.createdAt));
  }

  async createOffer(offerData: any) {
    const result = await db.insert(schema.offers).values(offerData).returning();
    return result[0];
  }

  async updateOffer(id: string, offerData: any) {
    const result = await db.update(schema.offers)
      .set({ ...offerData, updatedAt: new Date() })
      .where(eq(schema.offers.id, id))
      .returning();
    return result[0];
  }

  // ==================== SUBSCRIPTIONS ====================
  async createSubscriptionRecord(investorId: string, subscriptionData: any) {
    // Update the investor record
    await this.updateCommonInvestor(investorId, {
      hasForeclosureSubscription: true,
      foreclosureSubscriptionExpiry: subscriptionData.expiryDate,
      subscriptionPlan: subscriptionData.planType.toLowerCase()
    });
    
    // Store in foreclosure_subscriptions table
    const result = await db.insert(schema.foreclosureSubscriptions).values({
      leadId: investorId,
      counties: ['ALL'], // Default to all counties
      subscriptionType: subscriptionData.planType,
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date()
    }).returning();
    
    return result[0];
  }

  async updateSubscriptionStatus(investorId: string, isActive: boolean) {
    // Update the investor record
    const result = await db.update(schema.commonInvestors)
      .set({ 
        hasForeclosureSubscription: isActive,
        updatedAt: new Date()
      })
      .where(eq(schema.commonInvestors.id, investorId))
      .returning();
    
    // Also update any subscription records
    await db.update(schema.foreclosureSubscriptions)
      .set({ 
        isActive: isActive,
        updatedAt: new Date()
      })
      .where(eq(schema.foreclosureSubscriptions.leadId, investorId));
    
    return result[0];
  }

  // ==================== AUTHENTICATION ====================
  
  // Common Investor Authentication
  async getCommonInvestorByEmail(email: string) {
    const result = await db.select().from(schema.commonInvestors)
      .where(eq(schema.commonInvestors.email, email));
    return result[0] || null;
  }

  async authenticateCommonInvestor(username: string, password: string) {
    const investor = await this.getCommonInvestorByUsername(username);
    if (!investor) {
      return null;
    }

    const isValid = await bcrypt.compare(password, investor.password);
    if (!isValid) {
      return null;
    }

    return investor;
  }

  // Institutional Investor Authentication
  async getInstitutionalInvestorByEmail(email: string) {
    const result = await db.select().from(schema.institutionalInvestors)
      .where(eq(schema.institutionalInvestors.email, email));
    return result[0] || null;
  }

  async authenticateInstitutionalInvestor(username: string, password: string) {
    const investor = await this.getInstitutionalInvestorByUsername(username);
    if (!investor || !investor.password) {
      return null;
    }

    const isValid = await bcrypt.compare(password, investor.password);
    if (!isValid) {
      return null;
    }

    return investor;
  }

  // Partner Authentication
  async getPartnerByEmail(email: string) {
    const result = await db.select().from(schema.partners)
      .where(eq(schema.partners.email, email));
    return result[0] || null;
  }

  async authenticatePartner(username: string, password: string) {
    const partner = await this.getPartnerByUsername(username);
    if (!partner) {
      return null;
    }

    const isValid = await bcrypt.compare(password, partner.password);
    if (!isValid) {
      return null;
    }

    return partner;
  }

  // ==================== SESSION MANAGEMENT ====================
  
  // Common Investor Sessions
  async createCommonInvestorSession(investorId: string, sessionToken: string, expiresAt: Date) {
    const result = await db.insert(schema.commonInvestorSessions).values({
      investorId,
      sessionToken,
      expiresAt,
      createdAt: new Date()
    }).returning();
    return result[0];
  }

  async getCommonInvestorSession(sessionToken: string) {
    const result = await db.select().from(schema.commonInvestorSessions)
      .where(eq(schema.commonInvestorSessions.sessionToken, sessionToken));
    return result[0] || null;
  }

  async deleteCommonInvestorSession(sessionToken: string) {
    await db.delete(schema.commonInvestorSessions)
      .where(eq(schema.commonInvestorSessions.sessionToken, sessionToken));
  }

  async cleanupExpiredSessions() {
    await db.delete(schema.commonInvestorSessions)
      .where(gte(schema.commonInvestorSessions.expiresAt, new Date()));
  }

  // Institutional Investor Sessions
  async createInstitutionalSession(investorId: string, sessionToken: string, expiresAt: Date) {
    const result = await db.insert(schema.institutionalSessions).values({
      investorId,
      sessionToken,
      expiresAt,
      createdAt: new Date()
    }).returning();
    return result[0];
  }

  async getInstitutionalSession(sessionToken: string) {
    const result = await db.select().from(schema.institutionalSessions)
      .where(eq(schema.institutionalSessions.sessionToken, sessionToken));
    return result[0] || null;
  }

  async deleteInstitutionalSession(sessionToken: string) {
    await db.delete(schema.institutionalSessions)
      .where(eq(schema.institutionalSessions.sessionToken, sessionToken));
  }

  // ==================== UTILITY FUNCTIONS ====================
  
  generateSessionToken(): string {
    return randomUUID() + '-' + Date.now();
  }

  generateEmailVerificationToken(): string {
    return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
  }

  generatePhoneVerificationCode(): string {
    return Math.floor(100000 + Math.random() * 900000).toString();
  }

  async hashPassword(password: string): Promise<string> {
    return await bcrypt.hash(password, 12);
  }
}